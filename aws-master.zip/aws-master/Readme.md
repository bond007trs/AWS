AWS Assets


This repository is to maintain assests for AWS related automations. 
